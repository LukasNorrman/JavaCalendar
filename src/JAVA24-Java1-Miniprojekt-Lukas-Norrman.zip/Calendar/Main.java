package Calendar;

public class Main extends Kalender {

    public static void main(String[] args) {

//Kallar på metoden
        start();

//Kallar på metod 2
//        start2();

//Kallar på metod 3
//        start3();
    }
}